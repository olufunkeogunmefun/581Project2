package com.example.compass0;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.lang.Object;


public class MainActivity extends AppCompatActivity implements SensorEventListener{
    private TextView textView;
    private TextView textView2;
    private ImageView imageView;

    private SensorManager sensorManager;
    private Sensor accelerometerSensor, magnetometerSensor;

    private float[] lastAccelerometer = new float[3];
    private float[] lastMagnetometer = new float[3];
    private float[] rotationMatrix = new float[9];
    private float[] orientation = new float[3];

    boolean isLastAccelerometerArrayCopied = false;
    boolean isLastMagnetometerArrayCopied = false;

    long lastUpdatedTime = 0;
    float currentDegree = 0f;
    private int numStar;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        textView = findViewById(R.id.textView);
        imageView = findViewById(R.id.imageView);
        textView2 = findViewById(R.id.textView2);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnetometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        /*Button btn_sub;
        btn_sub = (Button) findViewById(R.id.btn_sub);

        btn_sub.setOnClickListener(new View.OnClickListener()){
            public void OnClick(View view){
                Intent i = new Intent(getApplicationContext(), PopActivity.class);
                startActivity(i);
            }
        }*/
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if(sensorEvent.sensor == accelerometerSensor){
            System.arraycopy(sensorEvent.values,0,lastAccelerometer,0,sensorEvent.values.length);
            isLastAccelerometerArrayCopied = true;
        }else if(sensorEvent.sensor == magnetometerSensor){
            System.arraycopy(sensorEvent.values,0,lastMagnetometer,0,sensorEvent.values.length);
            isLastMagnetometerArrayCopied = true;
        }

        if(isLastAccelerometerArrayCopied && isLastMagnetometerArrayCopied && System.currentTimeMillis()- lastUpdatedTime> 250){
            SensorManager.getRotationMatrix(rotationMatrix,null, lastAccelerometer, lastMagnetometer);
            SensorManager.getOrientation(rotationMatrix, orientation);

            float azimuthInRadians = orientation[0];
            float azimuthInDegrees = (float) Math.toDegrees(azimuthInRadians);

            RotateAnimation rotateAnimation =
                    new RotateAnimation(currentDegree, -azimuthInDegrees, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
            rotateAnimation.setDuration(250);
            rotateAnimation.setFillAfter(true);
            imageView.startAnimation(rotateAnimation);

            currentDegree = -azimuthInDegrees;
            lastUpdatedTime = System.currentTimeMillis();


            int x = (int)azimuthInDegrees;
            numStar= (int)azimuthInDegrees;
            if (x < 0){
                x = 360 + x;

            }
            if (x == 90){
             finish();
             System.exit(0);
            }
            textView.setText(x + "°");
            Button button = (Button) findViewById(R.id.button);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String strLen = textView.getText().toString();
                   if (strLen.length()==4){
              textView2.append("***");
           }
                   
                   else if (strLen.length() == 3){
                       textView2.append("**");
                   }
                   else {
                       textView2.append("*");
                    }
                    String passLen = textView2.getText().toString();
                    if(passLen.length() == 4){
                        finish();
                        System.exit(0);
                    }
                    else if(passLen.length() > 4){
                        Intent i = new Intent(getApplicationContext(), PopActivity.class);
                        startActivity(i);
                    }
                }
            });
//            if (x>=100 && x<360){
//                textView2.setText("***");
            //}


        }
    }


    public void openActivity2(){
    Intent intent = new Intent(this, Activity2.class);
    startActivity(intent);

    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume(){
        super.onResume();

        sensorManager.registerListener(this, accelerometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, magnetometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();

        sensorManager.unregisterListener(this,accelerometerSensor);
        sensorManager.unregisterListener(this,magnetometerSensor);
    }
}